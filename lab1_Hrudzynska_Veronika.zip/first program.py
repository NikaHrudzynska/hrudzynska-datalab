import sys
sys.version

pip --version